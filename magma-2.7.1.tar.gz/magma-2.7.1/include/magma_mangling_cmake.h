#ifndef MAGMA_MANGLING_CMAKE_H
#define MAGMA_MANGLING_CMAKE_H

/* Empty file. See magma_mangling.h
 * When using CMake, this gets replaced by Fortran name mangling. */

#endif  // MAGMA_MANGLING_CMAKE_H
